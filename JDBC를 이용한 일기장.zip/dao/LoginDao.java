package sist.com.dao;

import java.awt.List;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import sist.com.bean.LoginModel;
import sist.com.bean.MemberModel;
import sist.com.jdbc.EmpBean;
import sist.com.util.ServiceUtil;
import sist.com.view.DJtableView;

public class LoginDao {

	static Connection connection;
	static PreparedStatement psPreparedStatement;
	static {
		connection = ServiceUtil.getConnection();
	}

	public boolean idCheck(String id, String pw) {
		
		String sql = "SELECT ID, PASSWORD, NAME FROM LOGINMEMBER WHERE ID = ?";
		ResultSet rs = null;

		try {
			psPreparedStatement = connection.prepareStatement(sql);
			psPreparedStatement.setString(1, id);
			rs = psPreparedStatement.executeQuery();

			if (rs.next() && pw.trim().equals(rs.getString("password"))) {
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}


	public boolean idCheck2(String id) {
		String sql = "SELECT ID, PASSWORD, NAME FROM LOGINMEMBER WHERE ID = ?";
		ResultSet rs = null;

		try {
			psPreparedStatement = connection.prepareStatement(sql);
			psPreparedStatement.setString(1, id);
			rs = psPreparedStatement.executeQuery();
			
			while (rs.next()) {
				System.out.println(rs.getString("ID"));
				if(rs.getString("ID").equals(id)) {
					return true;
				}
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	

	public void createTableid(LoginModel model) { //���̵� ������ ���̺� �� ���� �����Ͽ� ������ DB������ �����ش�.
		String sql ="CREATE TABLE "+model.getId().trim() +"(" + 
				"NO NUMBER(5) CONSTRAINT "+model.getId().trim() +"_NO_PK PRIMARY KEY, " + 
				"WIRTEDATE VARCHAR2(50), " + 
				"TITLE VARCHAR2(50), " + 
				"CONTENT CLOB) ";

		try {
			connection.setAutoCommit(false); // �ڵ�Ŀ�� �Ұ�
			psPreparedStatement = connection.prepareStatement(sql);
			System.out.println("CreateTable Success");
			if (psPreparedStatement.executeUpdate() > 0) { // executeUpdate�������� insert��
				
				connection.commit(); // �ڵ� ����
			}
		} catch (Exception e) {
			// TODO: handle exception
			try {
				connection.rollback();// ���ܰ� �߻� �� �������Ƿ� try �� �ϳ��� �����Ͽ� ����
			} catch (Exception e2) {
				// TODO: handle exception
			}
			e.printStackTrace();
		}

	}

public void insertMember(LoginModel model) {
		String sql = "INSERT INTO LOGINMEMBER VALUES(?,?,?,?,?,LOGINDB_SEQ.NEXTVAL)"; // ?�� �ε��� ����

		try {
			connection.setAutoCommit(false); // �ڵ�Ŀ�� �Ұ�
			psPreparedStatement = connection.prepareStatement(sql);

			psPreparedStatement.setString(1, model.getId().trim()); // ���ε� ��
			psPreparedStatement.setString(2, model.getPassword().trim());
			psPreparedStatement.setString(3, model.getName().trim());
			psPreparedStatement.setString(4, model.getGender().trim());
			psPreparedStatement.setString(5, model.getBirthday().trim());

			if (psPreparedStatement.executeUpdate() > 0) { // executeUpdate�������� insert��
				System.out.println("SignUpSuccess");
				connection.commit(); // �ڵ� ����
			}
		} catch (Exception e) {
			// TODO: handle exception
			try {
				connection.rollback();// ���ܰ� �߻� �� �������Ƿ� try �� �ϳ��� �����Ͽ� ����
			} catch (Exception e2) {
				// TODO: handle exception
			}
			e.printStackTrace();
		}
	}
    }

}
