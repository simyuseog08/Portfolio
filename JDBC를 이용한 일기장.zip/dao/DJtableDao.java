package sist.com.dao;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;

import sist.com.bean.DJtableModel;
import sist.com.bean.DiaryModel;
import sist.com.bean.JtableModel;
import sist.com.bean.LoginModel;
import sist.com.bean.MemberModel;
import sist.com.jdbc.EmpBean;
import sist.com.util.ServiceUtil;

public class DJtableDao {

	static Connection connection;
	static PreparedStatement psPreparedStatement;
	static {
		connection = ServiceUtil.getConnection();
	}


	public java.util.List<DiaryModel> selectDiary(String id) {
		 
		String sql = "SELECT NO, WIRTEDATE, TITLE, CONTENT FROM "+id;
		ResultSet rs = null;
		ArrayList<DiaryModel> list = new ArrayList<DiaryModel>();
		try {
			psPreparedStatement = connection.prepareStatement(sql);
			rs = psPreparedStatement.executeQuery();

			while (rs.next()) {
				DiaryModel model = new DiaryModel();
				model.setNo(rs.getInt("no"));
				model.setWirtedate(rs.getString("wirtedate"));
				model.setTitle(rs.getString("title"));
				model.setContent(rs.getString("content"));
				list.add(model);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return list;
	}

public boolean deleteIndex(String no,String id) {
		String sql = "DELETE FROM "+ id.trim() +" WHERE NO = "+Integer.parseInt(no.trim());
		
		try {
			connection.setAutoCommit(false); // �ڵ�Ŀ�� �Ұ�
			psPreparedStatement = connection.prepareStatement(sql);
			System.out.println("Delete Success");
			
			if (psPreparedStatement.executeUpdate() > 0) {
				
				connection.commit(); // �ڵ� ����
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			try {
				connection.rollback();// ���ܰ� �߻� �� �������Ƿ� try �� �ϳ��� �����Ͽ� ����
				
			} catch (Exception e2) {
				// TODO: handle exception
				
			}
			e.printStackTrace();
		}
		return false;
	}

}
