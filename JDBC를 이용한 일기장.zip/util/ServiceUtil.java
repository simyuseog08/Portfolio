package sist.com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ServiceUtil {

	static Connection connection;
	static {
		
		try {
			Class.forName("oracle.jdbc.OracleDriver"); //
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger"); //�ּ�,������,��й�ȣ
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	public static Connection getConnection() {
		return connection;
	}
}
