package sist.com.bean;

public class DiaryModel {
	private int no;
	private String wirtedate;
	private String title;
	private String content;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getWirtedate() {
		return wirtedate;
	}
	public void setWirtedate(String wirtedate) {
		this.wirtedate = wirtedate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "DiaryModel [no=" + no + ", wirtedate=" + wirtedate + ", title=" + title + ", content=" + content + "]";
	}
	
	
	

}
