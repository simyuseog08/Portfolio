package sist.com.view;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import sist.com.bean.LoginModel;
import sist.com.dao.DJtableDao;
import sist.com.dao.LoginDao;

public class DeJtable extends JFrame implements ActionListener {

	private JLabel ja1, ja2, ja3, ja4, ja5, ja6;
	private JTextField jtf1, jtf2, jtf3;
	private JPanel pan1, pan2, pan3, pan4, pan7;
	private Font font = new Font("Bold", ALLBITS, 30);
	private JButton jbtn;
	private String id;
	
	DJtableDao dao = new DJtableDao();
	
	
		if (e.getSource() == jbtn) {
			if(dao.deleteIndex(jtf1.getText().trim(),id)==true) {
				JOptionPane.showMessageDialog(null, "�����Ϸ�");
				this.dispose();
			}else {
				JOptionPane.showMessageDialog(null, "��������");
				
			}
		}

	public DeJtable(String id) {
		
		this.id=id;
		
		// ȸ������ ��
		pan1 = new JPanel();

		ja1 = new JLabel("������ ��ȣ�� �Է����ּ���");
		ja1.setFont(font);
		pan1.add(ja1);
		// pan1.setBackground(Color.WHITE);
		this.add(pan1);

		// ���̵�
		pan2 = new JPanel();

		ja2 = new JLabel("��ȣ�Է�");
		jtf1 = new JTextField(15);

		pan2.add(ja2);
		pan2.add(jtf1);
		this.add(pan2);


		// ���ԿϷ� ��ư

		pan7 = new JPanel();

		jbtn = new JButton("�����ϱ�");
		jbtn.setFont(font);

		jbtn.addActionListener(this);

		pan7.add(jbtn);
		this.add(pan7);

		this.setVisible(true);
		this.setBounds(200, 200, 500, 500);
		this.setLayout(new GridLayout(7, 1));
	}

}
