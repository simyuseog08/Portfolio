package sist.com.view;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import sist.com.dao.DJtableDao;
import sist.com.dao.LoginDao;
public class Login extends Frame implements ActionListener {
	private JTextField tfID,tfPw; 
	private JLabel jl1,jl2,jl3,jl4;
	private JButton jbtnLogin,jbtnJoin,jbtnCancel;
	private JPanel jp1;
	ImageIcon imageIcon=new ImageIcon("d:\\img\\dog.jpg"); //D:\\img\\train.jpg,e:\\img\\dog.jpg
	LoginDao dao = new LoginDao();
	
	
	public void clearForm() {
		tfID.setText(" ");
		tfPw.setText(" ");
		tfID.requestFocus();		
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jbtnCancel) {
			this.dispose();
		}
		
		if(e.getSource()==jbtnLogin) {
			if(dao.idCheck(tfID.getText().trim(), tfPw.getText().trim())) {
				new DiaryView(tfID.getText().trim());
				this.dispose();
				
			}else {
				clearForm();
			}			
		}
		
		if(e.getSource()==jbtnLogin) {
			
			if(dao.idCheck2(tfID.getText().trim())==true) {
				JOptionPane.showMessageDialog(null, "������");
			}else {
				JOptionPane.showMessageDialog(null, "������");
			}
		}
		
		if(e.getSource()==jbtnJoin) {
			new SignUp();
			
		}
		
	}
		

	public void login() {
		
		JPanel jPanel = new JPanel() { //jpanel �� paintcompoent�� �͸��޾� ���.

			@Override
			protected void paintComponent(Graphics g) {
				// TODO Auto-generated method stub
				g.drawImage(imageIcon.getImage(),0,0,null);
			
			}
			
		};
	
		
		jl1 = new JLabel("ID");
		tfID = new JTextField(15);
		
		jl2 = new JLabel("PW");
		tfPw = new JTextField(15);
		
		jbtnLogin=new JButton("�α���");
		jbtnJoin=new JButton("ȸ������");
		jbtnCancel=new JButton("����");
		//id
		jPanel.add(jl1);
		jPanel.add(tfID);
		
		
		//pw
		jPanel.add(jl2);
		jPanel.add(tfPw);
		
		
		//�α���
		jPanel.add(jbtnLogin);
		jbtnLogin.addActionListener(this);
		
		//ȸ������
		jPanel.add(jbtnJoin);
		jbtnJoin.addActionListener(this);
		
		//�ݱ�
		jPanel.add(jbtnCancel);
		jbtnCancel.addActionListener(this);
		
		//����
		jl4=new JLabel("����, �ϱ⾲�� �� ���� ���̳�.");
		Font font = new Font("�޸հ���ü", Font.BOLD, 35);
		jl4.setFont(font);
		jp1=new JPanel();
		
		jp1.add(jl4);
		
		this.add(jp1,"South");
		this.add(jPanel);
	
	}

	public Login() {
		login();
		this.pack();
		Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((d.width-this.getWidth())/2,(d.height-this.getHeight())/2);
		this.setBounds(200, 200, 1000, 700);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new Login();
		
	}
}
