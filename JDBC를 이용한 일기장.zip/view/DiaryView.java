package sist.com.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import sist.com.bean.DiaryModel;
import sist.com.bean.LoginModel;
import sist.com.dao.DiaryDao;

public class DiaryView extends JFrame implements ActionListener {
	private Label dateLabel,titleLabel,contentLabel,mainLabel;
	private Panel panel1,panel2,panel3,panel4,panel5;
	private TextField tfdate,tftitle;
	private JButton jbtnsave,jbtnopen,jbtnLogin;
	private TextArea tacontent;
	private JScrollPane jsp;
	private  String id;
	DiaryDao dao = new DiaryDao();
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jbtnsave) {
			DiaryModel model = new DiaryModel();
			model.setWirtedate(tfdate.getText().trim());
			model.setTitle(tftitle.getText().trim());
			model.setContent(tacontent.getText().trim());
			dao.insertDiary(model,id);
		}
		
		if(e.getSource()==jbtnopen) {
			
			new DJtableView(id);
		}
		
		if(e.getSource()==jbtnLogin) {
			new Login();
			this.dispose();
		}
		
	}


	public void init() {
		this.add("North",mainLabel=new Label());
		panel4=new Panel(new BorderLayout());
		panel1=new Panel();
		panel2=new Panel();
		panel3=new Panel();
		panel5=new Panel();
		
		panel1.add(dateLabel=new Label("�ۼ�����"));
		panel1.add(tfdate=new TextField(25));
		panel2.add(titleLabel=new Label("����       "));
		panel2.add(tftitle=new TextField(25));
		
		panel5.add(jsp=new JScrollPane(tacontent=new TextArea(42,100),JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		
		panel3.add(jbtnsave=new JButton("����"));
		jbtnsave.addActionListener(this);
		panel3.add(jbtnopen=new JButton("��Ϻ���"));
		jbtnopen.addActionListener(this);
		panel3.add(jbtnLogin=new JButton("�α׾ƿ�"));
		jbtnLogin.addActionListener(this);
		
		
		panel4.add(panel1);
		panel4.add("South",panel2);
		
		       
		this.add(panel4);	
		this.add("South",panel5);
		this.add("North",panel3);
	}
	
	
	public DiaryView() {
		super();
	}


	public DiaryView(String id) {
		init();
		this.id = id;
		this.setBounds(100,100,800,800);
		this.setVisible(true);
		this.setLocationRelativeTo(null);	
	}
	
	public static void main(String[] args) {
		new DiaryView();
	}

}
