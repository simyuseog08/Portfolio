package sist.com.view;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Choice;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import sist.com.bean.LoginModel;

import sist.com.dao.LoginDao;

public class SignUp extends JFrame implements ActionListener,ItemListener {

	private JLabel ja1, ja2, ja3, ja4, ja5, ja6,ja7,ja8;
	private JTextField jtf1, jtf2, jtf3;
	private JPanel pan1, pan2, pan3, pan4,pan5,pan6 ,pan7;
	private Font font = new Font("Bold", ALLBITS, 30);
	private JButton jbtn;
	private String birthday;
	Checkbox man,woman;
	CheckboxGroup group = new CheckboxGroup();
	Choice choice1,choice2,choice3;
	LoginDao dao = new LoginDao();
	
	
	

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==choice1) {
			System.out.println(choice1.getSelectedItem());
			
		}
		
		if(e.getSource()==choice2) {
			System.out.println(choice2.getSelectedItem());
			
		}
		
		if(e.getSource()==choice3) {
			System.out.println(choice3.getSelectedItem());
			
		}
		
		if(e.getSource()==man) {
			group.getSelectedCheckbox().getLabel();
			
		}
		
		if(e.getSource()==woman) {
			group.getSelectedCheckbox().getLabel();
			
		}
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		if (e.getSource() == jbtn) {
			LoginModel model = new LoginModel();
			model.setId(jtf1.getText().trim());
			model.setName(jtf2.getText().trim());
			model.setPassword(jtf3.getText().trim());
			model.setGender(group.getSelectedCheckbox().getLabel());
			birthday = choice1.getSelectedItem()+"/"+ choice2.getSelectedItem()+"/"+ choice3.getSelectedItem();
			model.setBirthday(birthday);
			
			System.out.println("����: "+group.getSelectedCheckbox().getLabel());
			System.out.println("�������: "+birthday);
			
			dao.insertMember(model);
			dao.createTableid(model);
			JOptionPane.showMessageDialog(this, "���ԿϷ�");
			this.dispose();
			
		}

	}

	public SignUp() {
		// ȸ������ ��
		pan1 = new JPanel();

		ja1 = new JLabel("ȸ������������ �Է����ּ���");
		ja1.setFont(font);
		pan1.add(ja1);
		// pan1.setBackground(Color.WHITE);
		this.add(pan1);

		// ���̵�
		pan2 = new JPanel();

		ja2 = new JLabel("���̵�");
		jtf1 = new JTextField(15);

		pan2.add(ja2);
		pan2.add(jtf1);
		this.add(pan2);

		// �̸�
		pan3 = new JPanel();

		ja3 = new JLabel("�̸�");
		jtf2 = new JTextField(15);

		pan3.add(ja3);
		pan3.add(jtf2);
		this.add(pan3);

		// ��й�ȣ
		pan4 = new JPanel();

		ja4 = new JLabel("��й�ȣ");
		jtf3 = new JTextField(15);

		pan4.add(ja4);
		pan4.add(jtf3);

		this.add(pan4);
		
		//����
		pan5=new JPanel();
		ja7=new JLabel("����");
		
		man = new Checkbox("����",false,group);
	
		
		woman = new Checkbox("����", false,group);
		
		pan5.add(ja7);
		pan5.add(man);
		pan5.add(woman);
		man.addItemListener(this);
		woman.addItemListener(this);
		
		this.add(pan5);
		
		
		//�������
		choice1 = new Choice();
		pan6 = new JPanel();
		ja8= new JLabel("�������");
		
		for(int i= 0; i <= 2018; i++) {
			if(i !=0 && i > 1899) {
			choice1.addItem(""+i);
			}
		
			
		}
		
		
		choice2 = new Choice();
		pan6 = new JPanel();
		
		for(int i =1; i <= 12; i++) {
			if(i!=0 &&i < 10) {
			choice2.addItem("0"+i);
			}else {
				choice2.addItem(""+i);
			}
			
		}
		
		
		choice3 = new Choice();
		pan6 = new JPanel();
		
		for(int i =1; i <= 31; i++) {
			if(i!=0 &&i < 10) {
			choice3.addItem("0"+i);
			}else {
				choice3.addItem(""+i);
			}
			
		}
		pan6.add(ja8);
		pan6.add(choice1);
		pan6.add(choice2);
		pan6.add(choice3);
		
		this.add(pan6);
		
		choice1.addItemListener(this);
		choice2.addItemListener(this);
		choice3.addItemListener(this);

		// ���ԿϷ� ��ư

		pan7 = new JPanel();

		jbtn = new JButton("ȸ�����ԿϷ�");
		jbtn.setFont(font);

		jbtn.addActionListener(this);

		pan7.add(jbtn);
		this.add(pan7);

		this.setVisible(true);
		this.setBounds(200, 200, 1000, 700);
		this.setLayout(new GridLayout(7, 1));
	}

}
