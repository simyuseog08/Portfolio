package sist.com.bean;

public class Board {
	private int rm;
	private int no; //시퀀스설정
	private String title;
	private String weiter;
	private String password;
	private String contents;
	private String regdate; //sysdate로 날짜 출력
	private int hit; //update 로 조회수 증가
	private String fileName;
	private int ref; //그룹번호
	private int step; //
	private int lev; //레벨
	private int pnum; //부모번호
	private int reply; //덧글 수
	private String job;
	
	
	
	public Board() {
		super();
	}
	public Board(int pnum, String job) {
		super();
		this.pnum = pnum;
		this.job = job;
	}
	
	
	
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getRm() {
		return rm;
	}
	public void setRm(int rm) {
		this.rm = rm;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWeiter() {
		return weiter;
	}
	public void setWeiter(String weiter) {
		this.weiter = weiter;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public int getLev() {
		return lev;
	}
	public void setLev(int lev) {
		this.lev = lev;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public int getReply() {
		return reply;
	}
	public void setReply(int reply) {
		this.reply = reply;
	}
	@Override
	public String toString() {
		return "Board [no=" + no + ", title=" + title + ", weiter=" + weiter + ", password=" + password + ", contents="
				+ contents + ", regdate=" + regdate + ", hit=" + hit + ", fileName=" + fileName + ", ref=" + ref
				+ ", step=" + step + ", lev=" + lev + ", pnum=" + pnum + ", reply=" + reply + "]";
	}
	
	
	
	
	
	

}
