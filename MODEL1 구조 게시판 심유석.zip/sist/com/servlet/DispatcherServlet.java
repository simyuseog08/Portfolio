package sist.com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DispatcherServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 
		// TODO Auto-generated method stub
		
	PrintWriter pw = resp.getWriter();
		
		String html = "<HTML><HEAD></HEAD><TITLE>HI</TITLE><BODY bgcolor='blue'> <img src='../webPro/img/0.jpg' width='200' height='200'><iframe width=\\\"560\\\" height=\\\"315\\\" src=\\\'https://www.youtube.com/embed/_fT9ezdZQ10\\\' frameborder=\\\"0\\\" allow=\\\"autoplay; encrypted-media\\\" allowfullscreen></iframe></BODY></HTML>";
		pw.print(html);
	}
	


}
