package sist.com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.net.httpserver.HttpServer;

public class ServletAction extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { //get,post������� ���డ��
		// TODO Auto-generated method stub
		
		PrintWriter pw = response.getWriter();
		
		String color= request.getParameter("color");
		System.out.println("color="+color);
		
		String html = "<HTML><HEAD></HEAD><TITLE>HI</TITLE><BODY bgcolor='"+color+"'> ADA</BODY></HTML>";
		pw.print(html);
		
		
		
	}

}
