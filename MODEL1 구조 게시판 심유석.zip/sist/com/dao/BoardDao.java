package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import javafx.scene.layout.Border;
import sist.com.bean.Board;

public class BoardDao {
	
private static SqlSessionFactory sessionFactory; //SqlSession
	
	static {
		sessionFactory = SqlSessionFactoryManger.getSqlSessionFactory();
	}
	
	
	
	public static Integer getSequence() {
		return sessionFactory.openSession().selectOne("getSequence");
	}
	
	public static Object selectInfoBoard(int no) {
		return sessionFactory.openSession().selectOne("selectInfoBoard",no);
	}
	
	public static int getTotalRow(HashMap<String, Object>map) {
		return sessionFactory.openSession().selectOne("getTotalRow",map);
	}
	
	public static void updateHit(int no) {
		SqlSession sqlSession =null;
		try {
			sqlSession=sessionFactory.openSession();
			sqlSession.update("updateHit", no);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) {
				sqlSession.close();
			}
		}
	}
	
	public static void updateMod(Board board) {
		SqlSession sqlSession =null;
		try {
			sqlSession=sessionFactory.openSession();
			sqlSession.update("updateMod", board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) {
				sqlSession.close();
			}
		}
	}
	
	public static List<Board>selectBoard(HashMap<String,Object> map){
		return sessionFactory.openSession().selectList("selectBoard",map);
	}
	
	public static void updateStep(Board board) {
		SqlSession sqlSession =null;
		try {
			sqlSession=sessionFactory.openSession();
			sqlSession.update("updateStep",board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) {
				sqlSession.close();
			}
		}
	}
	
	public static void updateReply(Board board) {
		SqlSession sqlSession =null;
		try {
			sqlSession=sessionFactory.openSession();
			sqlSession.update("updateReply",board);
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) {
				sqlSession.close();
			}
		}
	}
	
	public static String getPassWord(int no) {
		return sessionFactory.openSession().selectOne("getPassWord",no);
	}
	
	public static void deleteReply(Board board) {
		SqlSession sqlSession = null;
		try {
			sqlSession=sessionFactory.openSession();
			sqlSession.delete("deleteReply", board);
			sqlSession.commit();
		}catch (Exception e) {
		 e.printStackTrace();
		}finally {
			// TODO: handle finally clause
			if(sqlSession!=null) {
				sqlSession.close();
			}
		}
	}
	
	
	public static void insertBoard(Board board) {
		SqlSession sqlSession =null;
		try {
			sqlSession=sessionFactory.openSession();
			sqlSession.insert("insertBoard", board);
			
			sqlSession.commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) {
				sqlSession.close();
			}
		}
	}
	
	

}
